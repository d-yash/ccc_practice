<?php

class Sales_Model_Resource_Collection_Quote extends Core_Model_Resource_Collection_Abstract
{
}
<?php

class Calculator_Model_Resource_Collection_Calculator extends Core_Model_Resource_Collection_Abstract{

}
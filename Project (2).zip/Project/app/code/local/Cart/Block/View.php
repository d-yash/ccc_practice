<?php

class Cart_Block_View extends Core_Block_Template
{
    public function __construct()
    {
        $this->setTemplate('cart/view.phtml');
    }
    public function getQuoteItems()
    {       
        return Mage::getSingleton('sales/quote')->getItemCollection();
    }
    public function getQuote()
    {
        $quote = Mage::getSingleton('sales/quote');
        return $quote->load($quote->getId());
    }
    public function getDeleteUrl($id)
    {
        return $this->getUrl('sales/quote/delete?item_id=' . $id);
    }
}
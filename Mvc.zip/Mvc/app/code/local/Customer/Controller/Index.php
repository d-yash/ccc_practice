<?php

class Customer_Controller_Index{
    public function saveAction(){
        echo dirname(__FILE__);
    }
    public function deleteAction(){
        echo dirname(__FILE__);
    }
    public function updateAction(){
        echo dirname(__FILE__);
    }
    public function listAction(){
        echo dirname(__FILE__);
    }
}
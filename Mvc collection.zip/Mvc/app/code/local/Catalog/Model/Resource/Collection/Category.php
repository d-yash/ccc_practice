<?php

class Catalog_Model_Resource_Collection_Categroy{
    
}
<?php
include "../mvc/app/code/local/autoload.php";
include "../mvc/app/mage.php";

mage::init();

<?php

class Core_Model_DB_Table
{

}
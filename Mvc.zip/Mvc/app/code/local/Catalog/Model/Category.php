<?php

class Catalog_Model_Resource_Category{
    
}
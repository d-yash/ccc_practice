<?php

class Sales_Model_Resource_Order_Address
{
}
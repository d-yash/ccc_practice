<?php
class Customer_Controller_Quote_Address
{
    public function newAction()
    {
        echo "Quote Address New Action";
    }
    public function listAction()
    {
        echo "Quote Address List Action";
    }
    public function saveAction()
    {
        echo "Quote Address Save Action";
    }
    public function deleteAction()
    {
        echo "Quote Address Delete Action";
    }
}
<?php

class Banner_Controller_Index{
    
}
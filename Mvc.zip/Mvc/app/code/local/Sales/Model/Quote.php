<?php

class Sales_Model_Quote{
    
}
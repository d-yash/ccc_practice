<?php

class Page_Block_Home extends Core_Block_Layout{

}
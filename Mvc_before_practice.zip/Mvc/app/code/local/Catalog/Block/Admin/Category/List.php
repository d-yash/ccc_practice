<?php

class Catalog_Block_Admin_Category_List extends Core_Block_Template
{
    public function __construct()
    {
        $this->setTemplate('catalog/admin/category/list.phtml');
    }
    public function getCategoryList()
    {
        return Mage::getModel("catalog/category")->getCollection()
            ->getData();
    }
}

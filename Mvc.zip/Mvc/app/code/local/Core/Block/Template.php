<?php

class Core_Block_Template
{
    public function toHtml()
    {
    }
    public function addChild($key, $value)
    {
    }
    public function removeChild($key)
    {
    }
    public function getChild($key)
    {
    }
}

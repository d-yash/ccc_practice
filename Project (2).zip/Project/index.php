<?php

include("app\Mage.php");
include("app\code\local\autoload.php");

Mage::init();
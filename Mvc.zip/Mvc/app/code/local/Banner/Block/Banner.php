<?php

class Banner_Block_Banner{
    
}
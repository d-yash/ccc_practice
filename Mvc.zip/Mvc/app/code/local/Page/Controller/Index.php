<?php
class Page_Controller_Index{
    public function index(){
        echo dirname(__FILE__);
    }
}